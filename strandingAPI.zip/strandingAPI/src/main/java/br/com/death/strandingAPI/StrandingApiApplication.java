package br.com.death.strandingAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrandingApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StrandingApiApplication.class, args);
	}

}
