package br.com.death.strandingAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StrandingApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
